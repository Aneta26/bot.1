import os
from colorama import init, Fore, Back
init()
import re
import datetime

class Question:
    topics: dict = {}
    botName: str = 'MyBot'
    isFunction: bool = False
    isNeedInput: bool = True
    name: str
    settings: dict
    upTopic: 'Question'
    

    def __init__(self, settings: dict) -> None:
        
        if 'name' in settings:
            self.botName = settings['name']
        self.logName = 'dialogue-'+str(datetime.datetime.now().strftime("%d-%m-%Y_%H-%M-%S"))+'.txt'  
        if 'log' in settings:
            self.logPath = settings['log']
        else:
            self.logPath = './log_default.txt'
        
    
    def _clear(self, line):
        ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])') # видалення кольорів з тексту
        return ansi_escape.sub('', line)
    
    def print(self, msg: str):
        print(Back.LIGHTWHITE_EX + Fore.CYAN + msg + Fore.RESET+Back.RESET)
        self.log(self._clear(msg), 'bot')
    
    def log(self, msg: str, sender: str):
            
        with open(os.path.join(self.logName), 'a', encoding="utf-8") as f:
            f.write(sender + ': ' + msg + '\n')
        with open(os.path.join(self.logPath), 'a', encoding="utf-8") as f:
            f.write(sender + ': ' + msg + '\n')
        
    def writeRandomGreeting(self):
        ...
        
    def setInput(self, inp: str):
        self.input = inp
        self.processText()
    
    def processText(self):
        ... 
    
    def writeMessege(self):
        raise NotImplementedError()
    
    def writeList(self):
        self.print(str.join(', ', self.topics))
        