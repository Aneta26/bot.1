from bot_lib import Bot  
   
my_bot = Bot()
my_bot.start()